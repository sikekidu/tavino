TAVINO TWO-SIDED DOSSIER - EPISODE 1 DATA PACK
Who Really Supplies America's Plastic Goods? (HS 3925 & HS 3926)
Prepared by Tavino - China sourcing, verified. 26 Nov 2026.

WHAT THIS PACK IS
The data tables behind Episode 1 of the Two-Sided Dossier series, which reads the
US import record (demand side) against a China-side identity check of the names on
the bills (supply side). Headline finding: of the 9 biggest China-side "suppliers"
in these two chapters, 8 are logistics shells - freight forwarders, NVOCCs and
e-commerce parcel fronts. Exactly one is a real factory.

FILES
- shippers-identified.csv - the nine top China-side shipper names, each identified
  and given a verdict, with the decisive evidence and the source basis per figure.
- us-buyers-and-notes.csv - real US buyers found underneath the forwarder names,
  including the retailer programs that ship under a cargo agent's name.
- price-bands-pvc-blinds.csv - export-listing reference band for the episode's
  anchor product family (HS 392530 blinds/shutters).

SOURCES AND WINDOWS
- ImportYeti free HS pages, pulled 23 Nov 2026: top-supplier rankings for HS 3925
  and HS 3926 (the HS 3926 category totals approx. 11.9 million shipments;
  per-company ImportYeti counts are cited per row in shippers-identified.csv).
- August Amber Hk: ImportGenius company page - 4,199,045 US shipments, all
  categories (Nov 2006 - Nov 2026); 549,261 bills in HS 3926 alone (ImportYeti).
- ImportInfo / ImportDoor / Zauba / ImportGenius / Panjiva figures are as cited
  per company in the source_notes column of shippers-identified.csv. Windows vary
  by source and company (e.g. ImportInfo totals run 2012-2026 for some names,
  2022-2026 for others) and are never merged.
- Price layer: Alibaba.com export listings sampled via accio aggregation,
  Nov 2026 - a reference band only, not 1688 domestic prices.

THE METHOD (5 LINES)
1. Take the top shipper names on US bills of lading for the HS chapters.
2. Identify each name from public sources: registries, company sites, trade data.
3. Cross-check shipment physics: weight per bill, FCL vs LCL, parcel signature.
4. Check consignee shape: real business buyers vs individuals vs own affiliates.
5. Classify: real factory / trading arm / forwarder-NVOCC / parcel consolidator.

LIMITS
- All rankings are bill-count rankings: one house bill for a 2 kg parcel counts
  the same as one master bill for a full container. That asymmetry is the subject
  of this research, not a defect we can correct with public data.
- Trade-data sites aggregate US Customs bill-of-lading data and handle name
  variants differently, so totals differ slightly between them; each figure in
  this pack is used only inside its own source's basis, as noted per row.
- Windows differ by source and are never merged across sources.
- One name's corporate parentage (U.S. United Logistics, Ningbo) could not be
  confirmed from public sources and is marked unclear in the research file.

This is a remote desk check of public records, not an on-site factory audit.

Full report: https://sikekidu.github.io/tavino/who-supplies-americas-plastics/
Contact: tavino@muse.ai - Site: https://sikekidu.github.io/tavino/
