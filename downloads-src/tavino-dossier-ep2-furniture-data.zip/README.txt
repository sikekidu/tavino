TAVINO TWO-SIDED DOSSIER - EPISODE 2 DATA PACK
Who Really Supplies America's Furniture? (HS 9401 seats & HS 9403 other furniture)
Prepared by Tavino - China sourcing, verified. 26 Nov 2026.

WHAT THIS PACK IS
The data tables behind Episode 2 of the Two-Sided Dossier series, which reads the
US import record (demand side) against a China-side identity check of the names on
the bills (supply side). Headline finding: of the 8 biggest China/HK "suppliers" of
US furniture, four are e-commerce parcel consolidators holding ~86% of the top-8
bill volume, two are trading arms, and only two are real factories. The #1 name
alone (133,443 bills) outweighs the other seven combined.

FILES
- shippers-identified.csv - the top China/HK shipper names on HS 9401+9403 bills,
  each identified and given a verdict, with the decisive evidence.
- us-importers.csv - top-10 US importers for HS 9401 and HS 9403, plus one flagged
  non-buyer (CrimsonLogic US Inc).
- price-bands-anji-chairs.csv - export-listing price bands from Anji, Zhejiang,
  the chair cluster where this episode's verified factory sits.

SOURCES AND WINDOWS
- ImportYeti free HS pages (pulled 25-26 Nov 2026), lifetime totals: HS 9401 =
  5,150,814 US sea shipments, China origin 3,118,938 = 60.5%; HS 9403 = 11,348,146
  shipments, China origin 5,954,371 = 52.5%. Database updated 18 Nov 2026.
  (ImportYeti's ranking tables are JavaScript-rendered, so the top-10 lists in
  this pack are ImportDoor aggregations - the two bases are never mixed.)
- ImportDoor, window Jun 2018 - Oct 2026: shipper and importer counts aggregated
  over the five largest subheadings of each heading (~93-95% coverage; HS 9403
  also includes 9403.99). ImportDoor re-aggregates monthly - treat counts as +/-5%.
- Zauba kilogram test (China-exporter table, HS 9403.20): August Amber Hk -
  70,744 shipments totalling 183 metric tons, approx. 2.6 kg per shipment;
  Fujian Dav Technologies - 4,263 shipments totalling 73,800 metric tons,
  approx. 17.3 t per shipment. Same code, same ranking, a ~400x weight gap.

THE METHOD (5 LINES)
1. Take the top shipper names on US bills of lading for the HS chapters.
2. Identify each name from public sources: registries, company sites, trade data.
3. Cross-check shipment physics: weight per bill, FCL vs LCL, parcel signature.
4. Check consignee shape: real business buyers vs individuals vs own affiliates.
5. Classify: real factory / trading arm / forwarder-NVOCC / parcel consolidator.

LIMITS
- All rankings are bill-count rankings: one house bill for a 2 kg parcel counts
  the same as one master bill for a 17 t container. That asymmetry is the subject
  of this research, not a defect we can correct with public data.
- Windows differ by source (ImportYeti lifetime 2015-2026; ImportDoor Jun 2018 -
  Oct 2026; Zauba 2012-2026) and figures are never merged across sources; each
  figure is used only inside its own source's ranking.
- Two consolidators' registered Chinese names could not be confirmed from public
  English-language sources; their verdicts rest on shipment physics.
- Shipper names are truncated at ~40 characters in the source manifests.

This is a remote desk check of public records, not an on-site factory audit.

Full report: https://sikekidu.github.io/tavino/who-supplies-americas-furniture/
Contact: tavino@muse.ai - Site: https://sikekidu.github.io/tavino/
