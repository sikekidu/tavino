TAVINO TWO-SIDED DOSSIER - EPISODE 3 DATA PACK
Who Really Supplies America's Auto Parts? (HS 8708)
Prepared by Tavino - China sourcing, verified. 26 Nov 2026.

WHAT THIS PACK IS
The data tables behind Episode 3 of the Two-Sided Dossier series, which reads the
US import record (demand side) against a China-side identity check of the names on
the bills (supply side). Headline finding: auto parts inverts the Episode 2
pattern. Of the 8 biggest China/HK "suppliers" of US auto parts, six are real
factories holding 61.0% of the top-8 bill volume (13,857 of 22,705 bills); the
#1 name is Advance Auto Parts' own offshore sourcing desk (25.3%); and the only
parcel shell in the list holds just 13.7%.

FILES
- shippers-identified.csv - the top China/HK shipper names on HS 8708 bills: the
  eight identity-checked names with verdicts and decisive evidence, plus the
  names just below the cut, marked as not identity-checked.
- us-importers.csv - top-10 US importers for HS 8708, plus one flagged non-buyer
  (Vestas Nacelles America, a wind-turbine maker on the gear-box subheading).
- price-bands-brake-discs.csv - export-listing price bands for the episode's
  anchor product, brake discs / rotors (HS 870830.50.30 in the US schedule).

SOURCES AND WINDOWS
- ImportYeti free HS page (pulled 25 Nov 2026): HS 8708 lifetime total =
  7,609,442 US sea shipments; database updated 18 Nov 2026. ImportYeti's weight
  and TEU figures on this page are broken and are not used. Its China-filtered
  page is not obtainable in text fetch, so no ImportYeti-basis China share is
  reported for this heading.
- ImportDoor, window Jun 2018 - Oct 2026: shipper and importer counts aggregated
  over the eleven largest subheadings of HS 8708 (873,323 of the heading's
  901,286 bills, 96.9% coverage; Taiwan excluded from the China/HK shipper list).
  China-origin bills within the top 11: 223,748 = 25.6%. ImportDoor
  re-aggregates monthly - treat counts as +/-5%.
- Zauba kilogram test: the HS 870880 exporter table's August Amber row - 969
  shipments totalling 2.5 metric tons, approx. 2.6 kg per shipment - the
  identical figure Episode 2 measured for the same company under HS 9403.20.
  Real shippers in this lane run from approx. 5.3 t per bill (Tenneco Suzhou)
  upward.
- Price layer: Alibaba.com category listings, Aug-Sep 2026 - an export-listing
  reference band only, not 1688 domestic prices and not a landed cost. Excluded
  from the band: racing/performance 2-piece floating discs ($80-275) and
  big-brake caliper kits ($286-650/set), a separate niche.

THE METHOD (5 LINES)
1. Take the top shipper names on US bills of lading for the HS chapters.
2. Identify each name from public sources: registries, company sites, trade data.
3. Cross-check shipment physics: weight per bill, FCL vs LCL, parcel signature.
4. Check consignee shape: real business buyers vs individuals vs own affiliates.
5. Classify: real factory / trading arm / forwarder-NVOCC / parcel consolidator.

LIMITS
- All rankings are bill-count rankings: one house bill for a 2.6 kg parcel counts
  the same as one master bill for a multi-container load. That asymmetry is the
  subject of this research, not a defect we can correct with public data.
- Weight note: several per-bill averages exceed a single 40 ft container's
  payload (approx. 26 t) - Sensen approx. 52.8 t, Winhere approx. 37.9 t, Longji
  approx. 29.1 t - because bills in this lane routinely span multiple containers
  (Conmet Xin: 90 bills / 800 TEU in Aug 2022). The kilogram test discriminates
  at the order-of-magnitude level only; exact tonne figures are not comparable
  across shippers without TEU data. Sensen's 123k t Zauba total may also carry
  weight noise and is reported as-is with that flag.
- Declaration quirk: brake rotors are also filed under HS 841199 (turbine
  parts) - Crossroads' #1 HS code overall - so HS 870830 totals understate the
  rotor lane; the dedicated rotor report (36,589 bills) is the cleaner view.
- Windows differ by source (ImportYeti lifetime 2015-2026; ImportDoor Jun 2018 -
  Oct 2026; Zauba 2012-2026) and figures are never merged across sources; each
  figure is used only inside its own source's ranking.
- Two identifications rest on name matches that are exact but not spelled
  identically (Crossroads "Trading" vs the bill name "Trade"; ImportDoor's
  truncated "Hubei Henglong Automotive System Gr") - stated in the files rather
  than silently normalised.
- Shipper names are truncated at ~40 characters in the source manifests.

This is a remote desk check of public records, not an on-site factory audit.

Full report: https://tavinosourcing.com/who-supplies-americas-auto-parts/
Contact: tavino@muse.ai - Site: https://tavinosourcing.com/
